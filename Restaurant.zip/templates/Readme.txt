Thanks for downloading this template!

Template Name: Delicious
Template URL: https://bootstrapmade.com/delicious-free-restaurant-bootstrap-theme/
Author: BootstrapMade.com
License: https://bootstrapmade.com/license/
